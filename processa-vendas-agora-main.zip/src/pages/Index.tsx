import ProcessFlowApp from '@/components/ProcessFlowApp';

const Index = () => {
  return <ProcessFlowApp />;
};

export default Index;
